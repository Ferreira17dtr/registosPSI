ID:<?php echo e($editora->ide); ?><br>
Nome:<?php echo e($editora->nome); ?><br>
Nacionalidade:<?php echo e($editora->morada); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/editoras/show.blade.php ENDPATH**/ ?>