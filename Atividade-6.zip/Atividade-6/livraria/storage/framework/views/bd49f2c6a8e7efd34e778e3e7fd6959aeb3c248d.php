ID:<?php echo e($genero->id_genero); ?><br>
Desinação:<?php echo e($genero->designacao); ?><br>
Observações:<?php echo e($genero->observacoes); ?><br>

<?php $__currentLoopData = $genero->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($livro->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\PSI\Atividade-6\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>