ID:{{$editoras->id_editora}}<br>
Nome:{{$editora->nome}}<br>
Nacionalidade:{{$editora->morada}}